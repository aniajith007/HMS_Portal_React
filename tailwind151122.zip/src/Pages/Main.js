import React from 'react'
import Footer from '../Components/Footer';
import Navbar from '../Components/Navbar'
import HealthMealCountdown from './HealthMealCountdown'

function Main() {

  const datet  = new Date();
  if(datet.getDay()==4){
    console.log("Thu")
    if(datet.getHours()>=6 && datet.getHours()<=18 ){
      console.log("Hours Matched");
    }else{
      console.log("Time Over Baiyya");
    }
  }
  
  if(datet.getDay()==5){
    console.log("Fri");
  }
  console.log(datet);
  return (
    <>
    <Navbar/>    
    <HealthMealCountdown/>
    <Footer/>
    </>
  )
}

export default Main