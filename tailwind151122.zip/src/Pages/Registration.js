import { useEffect, useState } from "react";
import Card from "../Components/Card";
import CardMain from "../Components/CardMain";
import Navbar from "../Components/Navbar";
import Cancellation from "../Components/Cancellation";
import Hero3 from "../Components/Hero3";
import Footer from '../Components/Footer';


const RegHMS = () => {
  const [name, setName] = useState("");
  const [cc, setCC] = useState("");
  const [plant, setPlant] = useState("");
  const [weekdates,setWeekdates]= useState("");
  const [isReg,setIsreg] = useState(false);
  useEffect(() => {
    setName("Swaminathan G");
    setCC("12536");
    const fromdate = "14-11-22";
    const todate = "19-11-22";
    const weekdate = fromdate+" - "+todate;
    setWeekdates(weekdate);
    setPlant("Padi");
    //setIsReg if he is already registered!!
    setIsreg(true);
  }, []);
  return (
    <div>
    <Navbar />    
    <Hero3 ccno = {cc} name = {name} weekdates = {weekdates} plant = {plant} isReg={isReg}/>
    {isReg?<Cancellation/>:""} 
    </div>    
  );
};

export default RegHMS;
