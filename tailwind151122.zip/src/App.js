import { BrowserRouter, Routes, Route } from "react-router-dom";
import Login from './Pages/login';
import Logindaisyui from "./Pages/logindaisyui";
import Main from "./Pages/Main";
import RegHMS from "./Pages/Registration";
import Theme from "./Pages/Theme";
function App() {
  return (
    <BrowserRouter>
      <Routes>        
          <Route path="/" element={<Logindaisyui />} />
          <Route path="/logindaisyui" element={<Logindaisyui />} />
          <Route path="/main" element={<Main />} />
          <Route path="/reghms" element={<RegHMS />} />
          <Route path="/theme" element={<Theme />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
