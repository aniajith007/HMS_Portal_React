import React from 'react'
import Card from './Card'
import AnimatedText from 'react-animated-text-content';
import 'animate.css';

function Hero3(props) {
    return (
        <div class="container flex flex-col px-6 py-10 mx-auto space-y-6 lg:h-[32rem] lg:py-16 lg:flex-row lg:items-center dark:text-gray-200">

            <div class="flex items-center justify-center w-full h-96 lg:w-1/2 animate__animated animate__fadeInLeft animate__delay-1s">
                <Card ccno={props.ccno} name={props.name} />
                {//<img class="object-cover w-full h-full mx-auto rounded-md lg:max-w-2xl" src="https://images.unsplash.com/photo-1543269664-7eef42226a21?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1470&q=80" alt="glasses photo"/>
                }
            </div>

            <div class="w-full lg:w-1/2">
                <div class="lg:max-w-lg">
                    <h1 class="text-3xl font-bold tracking-wide text-gray-800 dark: text-gray-500 lg:text-5xl animate__animated animate__fadeIn">
                        Register <h1 className="text-blue-500 animate__animated animate__fadeIn animate__delay-1s">Here!</h1><h1 className="animate__animated animate__fadeIn animate__delay-2s">For</h1> <h1 className="text-orange-400 animate__animated animate__fadeIn animate__delay-2s">Health Meals!!</h1>
                    </h1>
                    <div class="mt-8 space-y-5">
                        <p class="flex items-center -mx-2 text-gray-700 dark: text-gray-500 ">
                            {/*<svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 mx-2 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>*/}

                            <img src='factory.png' className='m-2  animate__animated animate__fadeIn animate__delay-2s'/>

                            <span class="mx-2 font-bold animate__animated animate__fadeIn animate__delay-2s">Plant : {props.plant}</span>
                        </p>

                        {/*<p class="flex items-center -mx-2 text-gray-700 ">
                                <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 mx-2 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>

                                <span class="mx-2">Just Copy Paste Codeing</span>
                            </p>

                            <p class="flex items-center -mx-2 text-gray-700 ">
                                <svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 mx-2 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                                </svg>

                                <span class="mx-2">Easy to Use</span>
                </p>*/}
                    </div>
                </div>

                <div class="w-full mt-8 bg-transparent border rounded-md lg:max-w-sm dark:border-gray-700 focus-within:border-blue-400 focus-within:ring focus-within:ring-blue-300 dark:focus-within:border-blue-400 focus-within:ring-opacity-40  animate__animated animate__fadeIn animate__delay-3s">
                    {props.isReg ?
                        <div class="flex w-full max-w-sm overflow-hidden border-none bg-white rounded-md shadow-md dark:bg-gray-800">
                            <div class="flex items-center justify-center w-12 bg-emerald-500">
                                <svg class="w-6 h-6 text-white fill-current" viewBox="0 0 40 40" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M20 3.33331C10.8 3.33331 3.33337 10.8 3.33337 20C3.33337 29.2 10.8 36.6666 20 36.6666C29.2 36.6666 36.6667 29.2 36.6667 20C36.6667 10.8 29.2 3.33331 20 3.33331ZM16.6667 28.3333L8.33337 20L10.6834 17.65L16.6667 23.6166L29.3167 10.9666L31.6667 13.3333L16.6667 28.3333Z" />
                                </svg>
                            </div>

                            <div class="px-4 py-2 -mx-3">
                                <div class="mx-3">
                                    <span class="font-semibold text-emerald-500 dark:text-emerald-400">Registered</span>
                                    <p class="text-sm text-gray-600 dark:text-gray-200">Your Health-Meals was registered!</p>
                                </div>
                            </div>
                        </div>

                        : <form class="flex flex-col lg:flex-row">
                            <span className="flex-1 h-10 px-4 py-2 m-1 text-black bg-transparent border-none appearance-non focus:outline-none focus:placeholder-transparent focus:ring-0"><h1 className="font-bold">{props.weekdates}</h1></span>

                            <button type="button" class="h-10 px-4 py-2 m-1 text-white transition-colors duration-300 transform bg-blue-500 rounded-md hover:bg-blue-400 focus:outline-none focus:bg-blue-400">
                                Register
                            </button>
                        </form>}
                </div>
            </div>


        </div>

    )
}

export default Hero3